#include "Stack.h"

Stack::Stack()
{
    //ctor
}

Stack::~Stack()
{
    //dtor
}
