#include "StudentLink.h"

StudentLink::StudentLink()
{
    //ctor
}

StudentLink::~StudentLink()
{
    //dtor
}
